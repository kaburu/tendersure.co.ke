<?php

namespace app\models;

/**
 * Description of File
 *
 * @author Ambrose
 */
class File {

    public $name;
    public $size;
    public $url;
    public $thumbnailUrl;
    public $deleteUrl;
    public $deleteType;

}
