<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="shortcut icon" href="fav.jpg" />
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Tendersure - A Tender Management Solution</title>
        <style type="text/css">
            <!--
            body {
                background-image: url(images/bodybgnew.jpg);
                background-color: #FFFFFF;
            }
            -->
        </style>
        <link href="general.CSS" rel="stylesheet" type="text/css" />
        <style type="text/css">
            <!--
            .submenu {display: none;}
            -->
        </style>
        <style type="text/css">
            a {

                text-decoration:none;
                color: #000000;
            }
            a:hover
            {
                text-decoration:none;
                color: #660033;

            }
            .style74 {
                color: #B52D2A;
                font-family: Calibri;
                font-weight: bold;
                font-size: 14px;
            }
            .style75 {font-size: 16px}
        </style>
        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-44778456-1', 'tendersure.co.ke');
            ga('send', 'pageview');

        </script>

    </head>

    <body>
        <table width="1010" height="20" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>
                <td valign="top">&nbsp;</td>
                <td colspan="3" valign="top"><img src="http://www.tendersure.co.ke/images/topbanner.png" width="999" height="133" border="0" usemap="#Map2" />
                    <map name="Map2" id="Map2">
                        <area shape="rect" coords="801,48,997,132" href="contact_us.php" />
                        <area shape="rect" coords="847,1,884,40" href="https://www.facebook.com/pages/QED-Solutions-Ltd/530951066926546 " target="_blank" />
                        <area shape="rect" coords="888,-1,922,39" href="https://twitter.com/QEDSolutionsltd" target="_blank" />
                        <area shape="rect" coords="930,0,963,37" href="http://www.youtube.com/watch?v=rJG7KaDrBO8" target="_blank" />
                    </map></td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td height="60" colspan="3" valign="middle"><img src="http://www.tendersure.co.ke/images/menu.png" name="image1" width="1000" height="50" border="0" usemap="#MapMap" id="image1" /></td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td colspan="3" valign="middle">&nbsp;</td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td colspan="3" valign="middle"><a href="http://www.qedtendersure.com/" target="_blank"><img src="http://www.tendersure.co.ke/images/cfcstanbicprequa.gif" width="1000" height="78" border="0" /></a>    </td>
            </tr>
            <?php //= $content ?>
            <tr>
                <td valign="top">&nbsp;</td>
                <td colspan="3" valign="middle">&nbsp;</td>
            </tr>

            <tr>
                <td valign="top">&nbsp;</td>
                <td width="387" valign="top"><p class="welcome">Welcome To Tendersure</p>
                    <p align="left" class="style74">&quot; <span class="style75">The Next Generation of E-Procurement</span> &quot;</p>
                    <p align="justify" class="small-text2">Changing the world, one tender at a time.   Good governance, transparency and system integrity will be the results   after the Tendersure system is embedded in Kenya &rsquo;s corporate and   government bodies. </p>
                    <p align="justify" class="small-text2">More and more leading organisations are playing the   game by the rules, meaning there is no way back for the ones who are not   yet using the system. Tendersure clears the air in the misty haze   around tenders and the procurement thereof.</p>
                    <p align="justify" class="small-text2"><strong>TenderSure System</strong> is a web based tendering tool that takes advantage of   the  many benefits that digital data offers. Bids are sealed and can   only be viewed  by authorised partiescutting down on project time,   tender period and reducing  risk and cost.</p></td>
                <td width="16" valign="top"><p class="welcome">&nbsp;</p>    </td>
                <td width="607" valign="top"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="606" height="332">
                        <param name="movie" value="http://www.tendersure.co.ke/ani.swf" />
                        <param name="quality" value="high" />
                        <embed src="ani.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="606" height="332"></embed>
                    </object></td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td height="40" colspan="3" valign="middle"><div align="center">
                        <marquee behavior="alternate">
                            <a href="demo_request.php"><img src="http://www.tendersure.co.ke/images/clickhere.png" width="778" height="35" border="0" /></a>
                        </marquee>
                    </div></td>
            </tr>
            <tr>
                <td width="4" valign="top">&nbsp;</td>
                <td height="20" colspan="3" valign="middle"><p align="center"><a href="products_tendersure.php"><img src="images/line.png" width="1000" height="1" border="0" /></a></p>        </td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td height="40" colspan="3" valign="middle" class="welcome">The Tendersure System </td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td colspan="3" valign="top"><table width="996" border="0" align="center" cellpadding="0" cellspacing="0">

                        <tr>
                            <td width="311" height="100"><div align="center"><a href="products_tendersure.php"><img src="http://www.tendersure.co.ke/images/tendersure3.png" width="310" height="155" border="0" /></a></div></td>
                            <td width="28" rowspan="2" class="style65">&nbsp;</td>
                            <td width="314"><div align="center"><a href="products_inspectionone.php"></a><a href="products_tendersure.php"><img src="http://www.tendersure.co.ke/images/tendersure4.png" width="310" height="155" border="0" /></a></div></td>
                            <td width="33" rowspan="2" class="style65">&nbsp;</td>
                            <td width="310"><div align="center"><a href="products_tendersure.php"><img src="http://www.tendersure.co.ke/images/tendersure5.png" width="310" height="155" border="0" /></a><a href="products_edoc.php"></a></div></td>
                        </tr>
                        <tr>
                            <td height="120" valign="middle" class="small-text2"><div>
                                    <ul>
                                        <li>Save Time</li>
                                        <li>Save Cost</li>
                                        <li>Save Space</li>
                                        <li>Save Trees</li>
                                        <li>Procure Quickly</li>
                                    </ul>
                                </div></td>
                            <td valign="middle" class="small-text2"><div>
                                    <ul>
                                        <li>Secure Communication</li>
                                        <li>Level Playing Field</li>
                                        <li>Competitive Bids</li>
                                        <li>Trust</li>
                                        <li>Security</li>
                                        <li>Procure Securely</li>
                                    </ul>
                                </div>          </td>
                            <td valign="middle" class="small-text2"><div>
                                    <ul>
                                        <li>Transparent Communication</li>
                                        <li>Fight Corruption</li>
                                        <li>Accessible Outcomes</li>
                                        <li>International Credibility</li>
                                        <li>Fairness</li>
                                        <li>Procure Openly</li>
                                    </ul>
                                </div>          </td>
                        </tr>

                    </table></td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td height="20" colspan="3" valign="middle"><a href="products_tendersure.php"><img src="http://www.tendersure.co.ke/images/line.png" width="1000" height="1" border="0" /></a></td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td height="40" colspan="3" valign="middle"><span class="welcome">Some of Our Clients/Partners on Tendersure </span></td>
            </tr>

            <tr>
                <td valign="top">&nbsp;</td>
                <td height="30" colspan="3" valign="middle" class="style65"><div align="center"><marquee direction="left">
                            <a href="clientelle.php"><img src="http://www.tendersure.co.ke/images/clientelle.fw.png" width="3360" height="95" border="0" /></a>
                        </marquee></div></td>
            </tr>
            <tr>
                <td valign="top">&nbsp;</td>
                <td height="20" colspan="3" valign="middle"><a href="products_tendersure.php"><img src="http://www.tendersure.co.ke/images/line.png" width="1001" height="1" border="0" /></a></td>
            </tr>
        </table>
        <table width="1012" align="center">
            <tr>
                <td height="25" colspan="2"><div align="center"><a href="news_and_articles.php"><img src="http://www.tendersure.co.ke/images/awards.png" width="538" height="157" border="0" /></a></div></td>
            </tr>
            <tr>
                <td width="734" height="30"><div align="left"><span class="bottomtext">Copyright &copy; 2013 Tendersure. All Rights Reserved :: <a href="http://www.tendersure.co.ke/webmail" class="bottomtext2">Check Mail </a></span></div></td>
                <td width="229" class="bottomtext"><div align="right">Powered By <a href="http://www.heartbitsolutions.com" target="_blank" class="bottomtext2">Heartbit </a></div></td>
            </tr>
        </table>

        <map name="MapMap" id="MapMap">
            <area shape="rect" coords="2,0,58,49" href="index.php" />
            <area shape="rect" coords="65,-1,167,48" href="products_tendersure.php" />
            <area shape="rect" coords="171,1,268,64" href="products_tendersure_benefits.php" />
            <area shape="rect" coords="272,-1,410,49" href="demo_request.php" />
            <area shape="rect" coords="511,1,605,48" href="partners.php" />
            <area shape="rect" coords="613,1,737,50" href="news_and_articles.php" />
            <area shape="rect" coords="829,0,914,49" href="inquiries.php" /><area shape="rect" coords="745,2,826,47" href="questions_answers.php" /><area shape="rect" coords="417,1,505,50" href="clientelle.php" />
            <area shape="rect" coords="920,0,1001,51" href="contact_us.php" />
        </map>
    </body>
</html>
