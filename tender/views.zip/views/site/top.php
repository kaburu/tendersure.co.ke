<!DOCTYPE html>
<html class="jPanelMenu" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="author" content="Pesapal">
    <meta name="description" content=""> 
    <title>Pesapal API Integration</title>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    
    

</head>
<body >
	 <h1 align="center">Pesapal API Integration</h1>
 <div class="progress">
  <div class="progress-bar progress-bar-striped active"  role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
    <span class="sr-only">70% Complete</span>
  </div>
</div>

<div class="jumbotron" style="height:700px;" align="center">