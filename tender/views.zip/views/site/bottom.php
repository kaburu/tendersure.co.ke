</div>

<p align="right"><a href="https://www.pesapal.com/">&copy;Pesapal <?php echo date('Y');?></a></p>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    
    <script src="../bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>