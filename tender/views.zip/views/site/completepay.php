<div class="jumbotron" style="height:500px;" align="center">

    <div class="list-group" style="width:100%;">
        <a class="list-group-item active">
            <p class="list-group-item-text">Your payment has been received and is being processed. You will receive an email notification once done. Thank you.</p>
        </a>
    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<script src="bootstrap/js/bootstrap.min.js"></script>